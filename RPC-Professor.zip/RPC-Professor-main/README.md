# RPC em python
Código apresentado pelo professor em sala de aula com pequenos upgrades.
